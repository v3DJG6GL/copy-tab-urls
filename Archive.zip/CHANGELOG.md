## 1.0.2 (2023-10-16)

### Changes

* Published addon on AMO

## 1.0.1 (2023-10-03)

### Changes

* Tried & failed to publish addon on AMO

# 1.0.0 (2023-10-03)

### Changes

* 1.0 Stable release
* Copying URLs of selected tabs using tab context menu
* Support for [Tree Style Tab](https://addons.mozilla.org/firefox/addon/tree-style-tab)
